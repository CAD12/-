"""Example URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path,include
from account import login_render,login_views
urlpatterns = [
    # path('login_redirect',login_views.login_redirect,name='login_redirect'),        #暂时不做，等差不多结束之后开始学习微信的接口
    path('signup_redirect',login_render.signup_redirect,name='signup_redirect'),
    path('email_notify',login_render.email_notify,name='email_notify'),
    path('reset_notify',login_render.reset_notify,name='reset_notify'),
]
