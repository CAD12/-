#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:CAD

from django.conf.urls import url
from django.urls import path,re_path
from competition import set_render,cop_render


# 比赛url
urlpatterns = [
    path('',cop_render.home,name="index"),
    re_path('games/s/(\w+)',cop_render.games,name="query_games"),
    path('game',cop_render.game,name='game'),
    path('result',cop_render.result,name="result"),
    path('rank',cop_render.rank)
]

#配置比赛url
urlpatterns += [
    path('set',set_render.index,name='set_index'),
    path('set/bank',set_render.set_bank,name='set_bank'),
    path('set/bank/tdownload',set_render.template_download,name="template_download"),
    path('set/bank/upbank',set_render.upload_bank,name='upload_bank'),
    path('set/game',set_render.set_game,name='set_game'),
]