#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:CAD

import random
from utils.decorators import check_login,check_copstatus
from django.db import transaction
from django.views.decorators.csrf import csrf_exempt
from account.models import Profile,UserInfo
from competition.models import CompetitionKindInfo,BankInfo,ChoiceInfo,FillInBlankInfo,CompetitionQAInfo
from utils.errors import CompetitionNotFound,CompetitionError,ProfileError
from utils.response import json_response
from utils.check_utils import check_correct_num
from utils.redis.rrank import add_to_rank
from TimeConvert import TimeConvert as tc


@check_copstatus
@check_login
@transaction.atomic
def get_questions(request):
    '''
    获取题目信息接口
    :param request:请求对象 
    :return: 返回json数据;user_info:用户信息;kind_info：比赛信息；qu_id：比赛答题记录；questions：比赛随机后的题目;
    '''
    kind_id = request.GET.get('kind_id',"")  #获取kind_id
    uid = request.GET.get('uid',"")       # 获取uid
    try:   # 获取比赛信息
        kind_info = CompetitionKindInfo.objects.select_for_update().get(kind_id=kind_id)
    except CompetitionKindInfo.DoesNotExist:   #没有收到返回错误码100001
        return json_response(*CompetitionError.CompetitionNotFound)
    try:    # 获取题库信息
        bank_info = BankInfo.objects.get(bank_id=kind_info.bank_id)
    except BankInfo.DoesNotExist:      #没有收到返回错误码100004
        return json_response(*CompetitionError.BankInfoNotFound)
    try:     # 获取用户信息
        profile = Profile.objects.get(uid=uid)
    except Profile.DoesNotExist:    #没有收到返回错误码200001
        return json_response(*ProfileError.ProfileNotFound)
    qc = ChoiceInfo.objects.filter(bank_id=kind_info.bank_id)  # 选择题
    qf = FillInBlankInfo.objects.filter(bank_id=kind_info.bank_id)   # 填空题
    questions = []
    for i in qc.iterator():
        questions.append(i.data)
    for i in qf.iterator():
        questions.append(i.data)
    question_num = kind_info.question_num   # 出题数
    q_count = bank_info.total_question_num  # 总题数
    if q_count < question_num:   #出题数大于总题数，返回错误码100005
        return json_response(CompetitionError.QuestionNotSufficient)
    qs = random.sample(questions,question_num)   #随机分配题目
    qa_info = CompetitionQAInfo.objects.select_for_update().create(
        kind_id=kind_id,
        uid=uid,
        qsrecord = [q['question'] for q in qs],
        asrecord = [q['answer'] for q in qs],
        total_num = question_num,
        started_stamp = tc.utc_timestamp(ms=True,milli=True),     #设置开始时间戳
        started = True
    )
    for i in qs:  #剔除答案信息
        i.pop("answer")
    return json_response(200,'OK',{
        'kind_info':kind_info.data,
        'user_info':profile.data,
        'qa_id':qa_info.qa_id,
        'questions':qs
    })

@csrf_exempt
@check_login
@check_copstatus
@transaction.atomic
def submit_answer(request):
    '''
    提交答案接口
    :param request: 
    :return: 返回json数据，user_info:用户信息；qa_id：比赛答题记录标识；kind_id：比赛唯一标识
    '''
    stop_stamp = tc.utc_timestamp(ms=True,milli=True)    #结束时间戳
    qa_id = request.POST.get('qa_id',"")     #获取qa_id
    uid = request.POST.get("uid","")        #获取id
    kind_id = request.POST.get("kind_id","")
    answer = request.POST.get("answer","")
    try:   #获取比赛信息
        kind_info = CompetitionKindInfo.objects.get(kind_id=kind_id)
    except CompetitionKindInfo.DoesNotExist:
        return json_response(*CompetitionError.CompetitionNotFound)
    try:   #获取题库信息
        bank_info = BankInfo.objects.get(bank_id=kind_info.bank_id)
    except BankInfo.DoesNotExist:
        return json_response(*CompetitionError.BankInfoNotFound)
    try:   #获取用户信息
        profile = Profile.objects.get(uid=uid)
    except Profile.DoesNotExist:
        return json_response(*ProfileError.ProfileNotFound)
    try:  #获取答题log信息
        qa_info = CompetitionQAInfo.objects.select_for_update().get(qa_id=qa_id)
    except CompetitionQAInfo.DoesNotExist:
        return json_response(*CompetitionError.QuestionNotFound)

    answer = answer.rstrip('#').split('#')  #处理答案数据
    print(answer)
    total, correct, wrong, correct_list, wrong_list = check_correct_num(answer)   #检查答题情况
    print("++++"+str(total),str(correct),str(wrong),str(correct_list),str(wrong_list))
    print("------------------------->")
    qa_info.aslogrecord = answer
    qa_info.finished_stamp = stop_stamp
    qa_info.expend_time = stop_stamp- qa_info.started_stamp
    qa_info.finished = True
    print("------------------------->")
    qa_info.correct_num = correct if total == qa_info.total_num else 0
    print(str(qa_info.total_num)+"------------>"+str(qa_info.correct_num))
    qa_info.incorrect_num = wrong if total == qa_info.total_num else qa_info.total_num
    qa_info.save()   #保存答题log
    print("---->")
    if qa_info.correct_num == kind_info.question_num:  # 得分处理
        score = kind_info.total_score
    elif not qa_info.correct_num:
        score = 0
        print("---->12456")
    else:
        score = round((kind_info.total_score / kind_info.question_num) * correct, 3)
    qa_info.score = score  # 继续保存答题log
    print("------->"+str(qa_info.score))
    qa_info.save()
    kind_info.total_partin_num += 1  # 保存比赛数据
    kind_info.save()  # 比赛答题次数
    bank_info.partin_num += 1
    bank_info.save()  # 题库答题次数
    if (kind_info.period_time > 0) and (qa_info.expend_time > kind_info.period_time * 60 * 1000):  # 超时，不加入排行榜
        qa_info.status = CompetitionQAInfo.OVERTIME
        qa_info.save()
    else:  # 正常完成，加入排行榜
        print("<---->"+str(qa_info.score))
        add_to_rank(uid, kind_id, qa_info.score, qa_info.expend_time)
        print("===>>>"+str(qa_info.score))
        qa_info.status = CompetitionQAInfo.COMPLETED
        qa_info.save()
    return json_response(200, 'OK', {  # 返回JSON数据
        'qa_id': qa_id,
        'user_info': profile.data,
        'kind_id': kind_id,
    })
















