#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:CAD

from django.db import transaction
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from django.contrib.auth.models import User

from utils.response import json_response
from utils.errors import UserError

from business.models import BusinessAccountInfo
from account.models import Profile

@csrf_exempt
@transaction.atomic
def registry_biz(request):
    email = request.POST.get('email',"")   # 填写邮箱名称
    name = request.POST.get('name','')      # 填写机构名称
    username = request.POST.get('username',"")  # 获取填写的机构联系人
    phone = request.POST.get('phone',"")   # 填写获取到的手机号
    ctype = request.POST.get('type',BusinessAccountInfo.INTERNET)   # 获取机构类型
    flag = int(request.POST.get('flag',2))  #获取标记，代表新用户或者使用绑定的老用户
    uname = email.split('@')[0]
    if not User.objects.filter(username__exact=name).exists():
        final_name = username
    elif not User.objects.filter(username__exact=uname).exists():
        final_name = uname
    else:
        final_name = email
    if flag == 2:   # 如果标记为2，那么就为他创建新用户
        user = User.objects.create_user(
            username=final_name,
            email= email,
            password=settings.INIT_PASSWORD,
            is_active = False,
            is_staff = False,
        )
    if flag == 1:
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return json_response(*UserError.UserNotFound)
    pvalues = {
        'phone':phone,
        'name':final_name,
        'user_src':Profile.COMPANY_USER,
    }
    profile,_ = Profile.objects.select_for_update().get_or_create(email=email)  # 获取或创建用户信息
    for k,v in pvalues.items():
        setattr(profile,k,v)
    profile.save()
    bizvalues = {
        'company_name':name,
        'company_username':username,
        'company_phone':phone,
        'company_type':ctype,
    }
    biz,_ = BusinessAccountInfo.objects.select_for_update().get_or_create(
        email=email,
        defaults=bizvalues,
    )
    print("final_name,email,flag----------->",final_name,email,flag)
    return json_response(200,"OK",{
        'name':final_name,
        'email':email,
        'flag':flag,
    })

def check_biz(request):
    email = request.GET.get('email','')
    print("email---->",email)
    try:
        biz = BusinessAccountInfo.objects.get(email=email)
    except BusinessAccountInfo.DoesNotExist:
        biz = None
    print("bool---->", User.objects.filter(email=email).exists(),bool(biz))
    # print(request.session.get("uid",""))
    return json_response(200,'OK',{
        'userexists':User.objects.filter(email=email).exists(),
        'bizaccountexists':bool(biz)
    })














































