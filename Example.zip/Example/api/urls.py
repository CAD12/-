#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:CAD

from django.conf.urls import url
from django.urls import path,re_path
from account import login_views
from competition import set_views,game_views,rank_views
from business import biz_views

# account
urlpatterns = [
    path('login_vcode',login_views.login_vcode,name='login_qrcode'),
    path('signup',login_views.signup,name='signup'),
    path('sendmail',login_views.sendmail,name='sendmail'),
    path('login_normal',login_views.normal_login,name='normal_login'),
    path("resetpasswd",login_views.reset_password,name='reset_password'),
]

# rank
urlpatterns += [
    path('myrank', rank_views.get_my_rank, name='my_rank'),
]

# game
urlpatterns += [
    path("questions",game_views.get_questions,name="get_questions"),
    path('answer',game_views.submit_answer,name='submit_answer')
]


#set
urlpatterns += [
    re_path('banks/s/(\d+)',set_views.banks,name="query_banks"),
    re_path('banks/detail/(?P<bank_id>\w+)',set_views.bank_detail,name="bank_detail"),
    path('banks/set',set_views.set_bank,name='set_bank'),
]

#bussiness
urlpatterns += [
    path('regbiz',biz_views.registry_biz,name="registry_biz"),
    path('checkbiz',biz_views.check_biz,name='check_biz'),
]
