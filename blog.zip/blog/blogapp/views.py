import logging
from django.db import connection
from django.shortcuts import render,redirect
from blogapp.models import Category,Ad,Article,Comment,User
from django.core.paginator import Paginator,InvalidPage,EmptyPage,PageNotAnInteger
from django.contrib.auth.hashers import make_password
from blogapp.forms import *
# from django.
from django.contrib.auth import login,logout,authenticate

logger = logging.getLogger('blog.views')
# Create your views here.

def index(request):
    # try:
    #     f = open("sss.txt","r")
    # except Exception as e:
    #     logger.error(e)
    try:
        #广告数据
        ads = Ad.objects.all()
        #最新文章数据
        article_list = Article.objects.all()
        article_list = Paging(request,article_list)
        #文章归档
        #1、关于直接调用sql语句：
        # archive_list = Article.objects.raw("select id, DATE_FORMAT(date_publish,'%%Y-%%m') as col_date FROM blogapp_article ORDER BY date_publish")
        # for archive in archive_list:
        #     print(archive)
        # cursor  = connection.cursor()
        # cursor.execute("select DATE_FORMAT(date_publish,'%Y-%m') as col_date FROM blogapp_article ORDER BY date_publish")
        # archive_list = cursor.fetchall()
        # print(archive_list)
    except Exception as e:
        logger.error(e)
    return render(request,"index.html",locals())

def archive(request):
    try:
        #先获取客户端提交的信息
        year = request.GET.get('year',None)
        month = request.GET.get("month",None)
        #__i 表示忽略大小写，contains表示模糊查询
        article_list = Article.objects.filter(date_publish__icontains=year+"-"+month)
        article_list = Paging(request,article_list)
    except Exception as e:
        logger.error(e)
    return render(request, "archive.html", locals())

def article(request):
    try:
        id = request.GET.get("id",None)
        # print("---->"+id)
        try:
            article = Article.objects.get(pk=id)
        except Article.DoesNotExist:
            return render(request,"article.html",{"reason":'没有找到该文章'})

        #评论表单

        comment_form = CommentForm({'author': request.user.username,
                                    'email': request.user.email,
                                    'url': request.user.url,
                                    'article': id } if request.user.is_authenticated else{"article":id})
        #获取评论表单
        comments= Comment.objects.filter(article=article).order_by("id")
        comment_list = []
        for comment in comments:
            for item in comment_list:
                if not hasattr(item,'children_comment'):
                    setattr(item,"children_comment",[])
                if comment.pid == item:
                    item.children_comment.append(comment)
                    break
            if comment.pid is None:
                comment_list.append(comment)
    except Exception as e:
        logger.error(e)
    return render(request,'article.html',locals())

def comment_post(request):
    try:
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            # 获取表单信息
            comment = Comment.objects.create(username=comment_form.cleaned_data["author"],
                                             email=comment_form.cleaned_data["email"],
                                             url=comment_form.cleaned_data["url"],
                                             content=comment_form.cleaned_data["comment"],
                                             article_id=comment_form.cleaned_data["article"],
                                             user=request.user if request.user.is_authenticated else None)
            comment.save()
        else:
            return render(request, 'failure.html', {'reason': comment_form.errors})
    except Exception as e:
        logger.error(e)
    return redirect(request.META['HTTP_REFERER'])

def do_loger(request):
    try:
        if request.method == "POST":
            login_form = LoginForm(request.POST)
            if login_form.is_valid():
                #登录
                username = login_form.cleaned_data["username"]
                password = login_form.cleaned_data["password"]
                user = authenticate(username=username,password=password)
                if user is not None:
                    user.backend = 'django.contrib.auth.backends.ModelBackend'
                    login(request,user)
                else:
                    return render(request,'failure.html',{"reason":"登录验证失败"})
                return redirect(request.POST.get("source_url"))
            else:
                return render(request, 'failure.html', {"reason": login_form.errors})
        else:
            login_form = LoginForm()
    except Exception as e:
        logger.error(e)
    return render(request,"login.html",locals())

#注销
def do_logout(request):
    try:
        # print("===========")
        # print("------->",request.META['HTTP_REFERER'])
        logout(request)
    except Exception as e:
        logger.error(e)
    return redirect(request.META['HTTP_REFERER'])

#注册
def do_reg(request):
    try:
        if request.method == "POST":
            reg_form = RegForm(request.POST)
            if reg_form.is_valid():
                user = User.objects.create(username=reg_form.cleaned_data["username"],
                                           email=reg_form.cleaned_data["email"],
                                           url = reg_form.cleaned_data["url"],
                                           password = make_password(reg_form.cleaned_data["password"]))
                user.save()
                #登录
                user.backend = 'django.contrib.auth.backends.ModelBackend'
                login(request, user)
                return redirect(request.POST.get('source_url'))
            else:
                return render(request,"failure.html",{"reason":reg_form.errors})
        else:
            reg_form = RegForm()
    except Exception as e:
        logger.error(e)
    return render(request,"reg.html",locals())

#分页
def Paging(request,article_list):
    paginator = Paginator(article_list, 2)  # 分页，调用django自带的分页类
    try:
        page = int(request.GET.get('page', 1))
        article_list = paginator.page(page)
    except (EmptyPage, InvalidPage, PageNotAnInteger):
        article_list = paginator.page(1)
    return article_list