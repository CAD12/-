#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:CAD

from blog import settings
from blogapp.models import Category,Ad,Article,Comment
from django.db.models import Count

def global_setting(request):
    SITE_NAME = settings.SITE_NAME
    SITE_DESC = settings.SITE_DESC

    #评论排行
    comment_count_list = Comment.objects.values('article').annotate(comment_count = Count('article')).order_by('-comment_count')[:10]
    article_comment_list = [Article.objects.get(pk=comment['article']) for comment in comment_count_list]
    #分类信息获取
    category = Category.objects.all()
    distinctDate_list = []
    for distinctDate in Article.objects.distinct_date():
        distinctDate = distinctDate + "文章归档"
        distinctDate_list.append(distinctDate)
    archive_list = distinctDate_list
    return locals()