/**
 * Created by CAD on 2020/5/6.
 */
KindEditor.ready(function (K) {
    K.create("textarea[name=content]",{
        width:500,
        height:200,
        uploadJson: '/admin/upload/kindeditor',
    });
});
